/**
 * An interface class for food
 */
public interface Food {
    public String describe();
}
